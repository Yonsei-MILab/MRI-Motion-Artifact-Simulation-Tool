function varargout = mrimagef(im,clim,donot_setgray)
% h = mrimagef(im)
%
% displays a complex image into a colormap scaled from 1 to 64
% returns the handle for an image graphics object.


if ~isreal(im)
    mim=mag(im);    % mag() is more fast function than abs()
else
    mim=im;
end

if nargin<3
    donot_setgray = 0;
end

if nargin<2
    h=imagesc(mim);
else
    if isempty(clim)
        h=imagesc(mim);
    else
        if clim(2)<=clim(1)
            clim(2) = clim(1)+0.001;    % make max to larger
%             clim(1) = -2*mag(clim(2));  % make min to smaller
        end
        h=imagesc(mim,clim);
    end
end

if nargout>0
    varargout{1} = h;
end

if donot_setgray
    %axis image is the same as axis equal except that the plot box fits tightly
    %around the data.
    axis('image');

    % also, you probably don't care about the axes
    axis('off');
else
    mrinit;
end


